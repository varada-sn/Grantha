import React, { useState } from 'react';
import { Avatar, Badge, IconButton, Menu, MenuItem } from '@mui/material';
import { Person, ShoppingCart as ShoppingCartIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

export const Navbar = () => {
    const navigate = useNavigate();
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = (path) => {
        setAnchorEl(null);
        if (path) navigate(path);
    };

    return (
        <div className='px-5 z-50 py-[1.2rem] bg-gradient-to-b from-[#000000] to-[#3533cd] lg:px-20 flex justify-between items-center'> 
            {/* Logo */}
            <div>
                <a href="/">
                    <img src="/logo_transparent.png" alt="Grantha Logo" className="h-12 w-auto" />
                </a>
            </div>

            {/* Right Section */}
            <div className='flex items-center space-x-4 lg:space-x-10'> 
                {/* Account Dropdown */}
            <div className=''>
                {false?<Avatar sx={{bgcolor:"white", color:"#3533cd"}}>V</Avatar>:
                <IconButton onClick={()=>navigate("/home/login")}>
                    <Person sx={{ fontSize: "2rem", color: 'white' }}/>
                </IconButton>}
            </div>

                {/* Shopping Cart */}
                <div>
                    <Badge color="primary" badgeContent='3'>
                        <ShoppingCartIcon sx={{ color: "white", fontSize: "2rem" }} className="hover:scale-105 transition" />
                    </Badge>
                </div>
            </div>
        </div>
    );
};
