import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./LoginSignup.css";

import EmailIcon from "@mui/icons-material/Email";
import LockIcon from "@mui/icons-material/Lock";
import HomeIcon from "@mui/icons-material/Home";

export const LoginForm = () => {
  const navigate = useNavigate();

  // State for email, password, and role selection
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("CUSTOMER"); // Default to CUSTOMER

  // Function to handle login
  const handleLogin = async () => {
    try {
      const response = await axios.post("http://localhost:8085/auth/login", null, {
        params: { email, password, role }  // Sending email, password, and role
      });

      if (response.data.role === role) {
        navigate(role === "CUSTOMER" ? "/home" : "/home/supplierDashboard");
      } else {
        alert("Invalid email, password, or role!");
      }
    } catch (error) {
      console.error("Login failed", error);
      alert("Login failed. Please check your credentials.");
    }
  };

  return (
    <div>
      {/* Home Icon to go back to home */}
      <HomeIcon sx={{ color: "white", mx: 2, my: 2, fontSize: "2rem" }} onClick={() => navigate("/home")} />

      <div className="container">
        <div className="header">
          <div className="text">Login</div>
          <div className="underline"></div>
        </div>
        <div className="inputs">
          <div className="input">
            <EmailIcon sx={{ mx: 2 }} />
            <input 
              type="email" 
              placeholder="Email Id" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
            />
          </div>
          <div className="input">
            <LockIcon sx={{ mx: 2 }} />
            <input 
              type="password" 
              placeholder="Password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
            />
          </div>
          {/* Role Selection Dropdown */}
          <div className="input">
            <select value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="CUSTOMER">Customer</option>
              <option value="SUPPLIER">Supplier</option>
            </select>
          </div>
        </div>
        <div className="forgot-password">
          Forgot Password? <span>Click Here!</span>
        </div>
        <div className="submit-container">
          <div className="submit" onClick={handleLogin}>Login</div>
        </div>
        <div className="signup-message">
          Don't have an account? <span onClick={() => navigate("/home/signup")}>Sign Up!</span>
        </div>
      </div>
    </div>
  );
};