import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { pdfSearch } from "../State/pdfSearch/action";
import { podcastSearch } from "../State/podcastSearch/action"; // Import podcast search action
import { useLocation } from "react-router-dom";
import { BookOpen, FileText, Youtube, Podcast } from "lucide-react";
import SearchIcon from "@mui/icons-material/Search";

export const Search = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const initialQuery = params.get("query") || "";

  const [searchQuery, setSearchQuery] = useState(initialQuery);

  const dispatch = useDispatch();
  const { loading, results, error } = useSelector((state) => state.pdfSearch);
  const { podcastLoading, podcasts, podcastError } = useSelector((state) => state.podcastSearch);

  useEffect(() => {
    if (initialQuery) {
      dispatch(pdfSearch(initialQuery));
      dispatch(podcastSearch(initialQuery)); // Fetch podcasts
    }
  }, [dispatch, initialQuery]);

  const handleSearch = () => {
    dispatch(pdfSearch(searchQuery));
    dispatch(podcastSearch(searchQuery)); // Trigger podcast search
  };

  return (
    <div className="mx-auto p-4 bg-[#D0D6F8]">
      {/* Search Bar */}
      <div className="mb-8 flex justify-center">
        <input
          type="text"
          placeholder="Search by book name, author, genre..."
          className="p-3 w-1/2 border border-gray-300 rounded-lg shadow-md"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button
          className="ml-4 bg-[#3533cd] text-white p-3 rounded-lg hover:bg-blue-600 shadow-md"
          onClick={handleSearch}
        >
          <SearchIcon />
        </button>
      </div>

      {loading && <p className="text-center text-lg font-semibold text-gray-600 animate-pulse">Loading PDFs...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {podcastLoading && <p className="text-center text-lg font-semibold text-gray-600 animate-pulse">Loading Podcasts...</p>}
      {podcastError && <p className="text-red-500">{podcastError}</p>}

      <h1 className="text-3xl font-bold text-center mb-8 text-[#4F62D0]">
        Book Search Results
      </h1>

      {/* Grid with Three Separate Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Rental Card (Empty for now) */}
        <div className="bg-gray-100 p-6 rounded-lg shadow-lg text-center hover:shadow-xl transition">
          <div className="flex flex-col items-center mb-4">
            <BookOpen size={50} className="text-blue-500" />
            <p className="text-lg font-semibold mt-2 text-black">
              Available for Rent
            </p>
          </div>
          <p>Rental feature coming soon...</p>
        </div>

        {/* PDF Card (Middle Card - Displays All PDFs) */}
        <div className="bg-gray-100 p-6 rounded-lg shadow-lg text-center hover:shadow-xl transition">
          <div className="flex flex-col items-center mb-4">
            <FileText size={50} className="text-green-500" />
            <p className="text-lg font-semibold mt-2 text-black">
              Digital Copy (PDF)
            </p>
          </div>
          <div className="space-y-4">
            {results?.length > 0 ? (
              results.map((result, index) => (
                <div key={index} className="border p-4 rounded-lg bg-white">
                  <h3 className="font-medium text-black">{result.bookName}</h3>
                  <a
                    href={result.pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    View PDF
                  </a>
                </div>
              ))
            ) : (
              <p>No PDFs available.</p>
            )}
          </div>
        </div>

        {/* Podcast Card (New) */}
        <div className="bg-gray-100 p-6 rounded-lg shadow-lg text-center hover:shadow-xl transition">
          <div className="flex flex-col items-center mb-4">
            <Podcast size={50} className="text-red-500" />
            <p className="text-lg font-semibold mt-2 text-black">Podcasts</p>
          </div>
          <div className="space-y-4">
            {podcasts?.length > 0 ? (
              podcasts.map((podcasts, index) => (
                <div key={index} className="border p-4 rounded-lg bg-white">
                  <h3 className="font-medium text-black">{podcasts.bookName}</h3>
                  <a
                    href={podcasts.podcastUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    Listen Podcast
                  </a>
                </div>
              ))
            ) : (
              <p>No Podcasts available.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
