import axios from "axios";
import { VIDEO_SEARCH_REQUEST, VIDEO_SEARCH_SUCCESS, VIDEO_SEARCH_FAILURE } from "./actionType";
import { API_URL } from "../../Config/api";

// Video Search Action
export const videoSearch = (searchQuery) => async (dispatch) => {
    dispatch({ type: VIDEO_SEARCH_REQUEST });

    try {
        const { data } = await axios.get(`${API_URL}/api/youtube`, {
            params: { bookname: searchQuery, author: searchQuery, genre: searchQuery },
        });

        dispatch({ type: VIDEO_SEARCH_SUCCESS, payload: data });
    } catch (error) {
        const errorMessage = error.response?.data || "Something went wrong";
        dispatch({ type: VIDEO_SEARCH_FAILURE, payload: errorMessage });
    }
};