/*import { SEARCH_REQUEST, SEARCH_SUCCESS, SEARCH_FAILURE } from './actionType';

// Initial state for search
const initialState = {
  loading: false,
  results: [],
  error: null,
};

const searchReducer = (state = initialState, action) => {
  switch (action.type) {
    case SEARCH_REQUEST:
      return {
        ...state,
        loading: true,  // Loading state while fetching data
        error: null,    // Clear any previous errors
      };
    case SEARCH_SUCCESS:
      return {
        ...state,
        loading: false,  // Data has been fetched successfully
        results: action.payload,  // Save the fetched data
      };
    case SEARCH_FAILURE:
      return {
        ...state,
        loading: false,  // Finished loading
        error: action.payload,  // Save the error message
      };
    default:
      return state;
  }
};

export default searchReducer;
*/

import { PDF_SEARCH_REQUEST, PDF_SEARCH_SUCCESS, PDF_SEARCH_FAILURE } from './actionType';

const initialState = {
  loading: false,
  results: [],
  error: null,
};

const pdfSearchReducer = (state = initialState, action) => {
  switch (action.type) {
    case PDF_SEARCH_REQUEST:
      return { ...state, loading: true, error: null };
    case PDF_SEARCH_SUCCESS:
      return { ...state, loading: false, results: action.payload };
    case PDF_SEARCH_FAILURE:
      return { ...state, loading: false, error: action.payload };

    default:
      return state;
  }
};

export default pdfSearchReducer;
