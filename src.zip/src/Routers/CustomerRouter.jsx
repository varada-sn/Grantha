import React from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom'; // Import Router, Routes, Route, and useLocation
import { Navbar } from '../component/Navbar/Navbar'; // Navbar component
import { LoginForm } from '../component/LoginSignup/LoginForm'; // Login Form Component
import { Home } from '../component/Home/Home';
import { SignupForm } from '../component/LoginSignup/SignupForm';
import { Search } from '../component/Search/Search';

const Layout = () => {
  const location = useLocation(); // Get current route

  // Define routes where Navbar should NOT be displayed
  const hideNavbarRoutes = ["/home/login", "/home/signup"];

  return (
    <>
      {!hideNavbarRoutes.includes(location.pathname) && <Navbar />} {/* Conditionally render Navbar */}
      <Routes>
        <Route path="/" element={<Home/>} /> {/* Home page */}
        <Route path="/home" element={<Home />} /> {/* Home page */}
        <Route path="/home/login" element={<LoginForm />} /> {/* Login page */}
        <Route path="/home/signup" element={<SignupForm />} /> {/* Sign up page */}
        <Route path="/home/search" element={<Search />} /> {/* Search result page */}
      </Routes>
    </>
  );
};

export const CustomerRouter = () => {
  return (
    <Router>
      <Layout /> {/* Wrapped Layout component */}
    </Router>
  );
};
