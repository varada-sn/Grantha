import React from "react";
import { useNavigate } from "react-router-dom";
import "./LoginSignup.css";

import PersonIcon from "@mui/icons-material/Person";
import EmailIcon from "@mui/icons-material/Email";
import LockIcon from "@mui/icons-material/Lock";
import HomeIcon from '@mui/icons-material/Home';

export const LoginForm = () => {
  const navigate = useNavigate();

  return (
    <div>
        {/* Home Icon to go back to home */}
        <HomeIcon sx={{ color: "white", mx : 2, my: 2, fontSize: "2rem" }} onClick={() => navigate("/home")} />

    <div className="container">
      <div className="header">
        <div className="text">Login</div>
        <div className="uderline"></div>
      </div>
      <div className="inputs">
        <div className="input">
          <EmailIcon sx={{ mx: 2 }} />
          <input type="email" placeholder="Email Id" />
        </div>
        <div className="input">
          <LockIcon sx={{ mx: 2 }} />
          <input type="password" placeholder="Password" />
        </div>
      </div>
      <div className="forgot-password">
        Forgot Password? <span>Click Here!</span>
      </div>
      <div className="submit-container">
        <div className="submit">Login</div>
      </div>
      <div className="signup-message">
        Don't have an account? <span onClick={() => navigate("/home/signup")}>Sign Up!</span>
      </div>
    </div>
    </div>
  );
};
