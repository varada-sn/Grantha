import { Avatar, Badge, IconButton } from '@mui/material'
import { purple } from '@mui/material/colors'
import React from 'react'

import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Person } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

export const Navbar = () => {
    const navigate = useNavigate()
  return (
    <div className='px-5 z-50 py-[1.2rem] bg-gradient-to-b from-[#000000] to-[#3533cd] lg:px-20 flex justify-between'> 

        <div className='flex'>
            <a href="/">
                <img src="/logo_transparent.png" alt="Grantha Logo" className="h-12 w-auto" />
            </a>
        </div>

        <div className='flex items-center space-x-2 lg:space-x-10'> 
            <div className=''>
                {false?<Avatar sx={{bgcolor:"white", color:"#3533cd"}}>V</Avatar>:
                <IconButton onClick={()=>navigate("/home/login")}>
                    <Person sx={{ fontSize: "2rem", color: 'white' }}/>
                </IconButton>}
            </div>
            <div className=''>
                <Badge color="primary" badgeContent='3'>
                    <ShoppingCartIcon sx={{color:"white", fontSize:"2rem"}}></ShoppingCartIcon>
                </Badge>
            </div>
        </div>

    </div>
  )
}
