import axios from "axios";
import { PODCAST_SEARCH_REQUEST, PODCAST_SEARCH_SUCCESS, PODCAST_SEARCH_FAILURE } from "./actionType";
import { API_URL } from "../../Config/api";

// Podcast Search Action
export const podcastSearch = (searchQuery) => async (dispatch) => {
    dispatch({ type: PODCAST_SEARCH_REQUEST });

    try {
        const { data } = await axios.get(`${API_URL}/api/podcasts`, {
            params: { bookname: searchQuery, author: searchQuery, genre: searchQuery },
        });

        dispatch({ type: PODCAST_SEARCH_SUCCESS, payload: data });
    } catch (error) {
        const errorMessage = error.response?.data || "Something went wrong";
        dispatch({ type: PODCAST_SEARCH_FAILURE, payload: errorMessage });
    }
};
